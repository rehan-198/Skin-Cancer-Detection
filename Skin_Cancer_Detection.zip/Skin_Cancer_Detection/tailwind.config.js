/** @type {import('tailwindcss').Config} */
export default { darkMode: 'class', content: ['./index.html', './src/**/*.{js,jsx}'], theme: { extend: { colors: { brand: { 50:'#effbff', 100:'#d7f5ff', 500:'#0b9fc5', 600:'#087fa7', 700:'#096787' }, ink:'#102a43' }, boxShadow: { glow:'0 10px 35px rgba(11,159,197,.18)' } } }, plugins: [] };
