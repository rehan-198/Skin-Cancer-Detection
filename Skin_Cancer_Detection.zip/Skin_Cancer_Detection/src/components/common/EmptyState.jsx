import { Inbox } from 'lucide-react';
export default function EmptyState({ title='Nothing here yet', description='There is no data to display.', action }) { return <div className="card py-12 text-center"><Inbox className="mx-auto text-slate-300" size={40}/><h2 className="mt-3 font-bold">{title}</h2><p className="mt-1 text-sm text-slate-500">{description}</p>{action}</div>; }
