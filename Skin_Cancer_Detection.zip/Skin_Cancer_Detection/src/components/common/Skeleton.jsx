export default function Skeleton({ className = '' }) { return <div aria-label="Loading" className={`animate-pulse rounded-lg bg-slate-200 dark:bg-slate-800 ${className}`} />; }
