import { AlertCircle } from 'lucide-react';
export default function ErrorState({ onRetry }) { return <div role="alert" className="card border-red-200 text-center"><AlertCircle className="mx-auto text-red-500"/><p className="mt-2 font-semibold">We couldn’t load this content.</p><button onClick={onRetry} className="btn-secondary mt-4">Try again</button></div>; }
