import api, { usingMockApi } from './axios';
const mockUser = data => ({ token: 'demo-token', user: { name: data.name || 'Demo User', email: data.email, role: 'user' } });
export const login = async data => usingMockApi ? mockUser(data) : (await api.post('/auth/login', data)).data;
export const register = async data => usingMockApi ? mockUser(data) : (await api.post('/auth/register', data)).data;
export const forgotPassword = async data => usingMockApi ? { success: true } : (await api.post('/auth/forgot-password', data)).data;
