import api, { usingMockApi } from './axios';
import { mockPrediction } from '../data/mockData';
export const predict = async image => { if (usingMockApi) return { ...mockPrediction, gradcam_image: URL.createObjectURL(image) }; const body = new FormData(); body.append('image', image); return (await api.post('/predict', body)).data; };
