import api, { usingMockApi } from './axios';
import { mockHistory } from '../data/mockData';
export const getHistory = async () => usingMockApi ? mockHistory : (await api.get('/history')).data;
export const deleteHistoryItem = async id => usingMockApi ? { id } : (await api.delete(`/history/${id}`)).data;
