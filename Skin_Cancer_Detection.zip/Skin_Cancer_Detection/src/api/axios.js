import axios from 'axios';

const api = axios.create({ baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api', timeout: 20000 });
api.interceptors.request.use(config => { const token = localStorage.getItem('dermaai_token'); if (token) config.headers.Authorization = `Bearer ${token}`; return config; });
export const usingMockApi = import.meta.env.VITE_USE_MOCK_API !== 'false';
export default api;
