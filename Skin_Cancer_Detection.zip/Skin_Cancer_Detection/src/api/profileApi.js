import api, { usingMockApi } from './axios';
import { mockProfile } from '../data/mockData';
export const getProfile = async () => usingMockApi ? mockProfile : (await api.get('/profile')).data;
export const updateProfile = async payload => usingMockApi ? payload : (await api.put('/profile', payload)).data;
