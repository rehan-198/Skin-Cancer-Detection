# DermaAI frontend

DermaAI is a responsive React/Vite healthcare interface for AI-assisted skin lesion screening. It is intentionally frontend-only and runs entirely with mock data when `VITE_USE_MOCK_API=true`.

## Setup

```powershell
npm install
npm run dev
```

Use `npm run build` for a production build. Copy `.env.example` to `.env` to set the future backend URL.

## Backend integration

API adapters are in `src/api`. The prediction screen accepts `predicted_class`, `confidence`, `risk_level`, `class_probabilities`, and `gradcam_image` from `POST /predict`. Planned endpoints: auth, profile, prediction, and history. No server, database, or ML model is included.

## Main dependencies

React, Vite, Tailwind CSS, React Router, Axios, Lucide React, Recharts, Framer Motion, React Dropzone, and Sonner.
